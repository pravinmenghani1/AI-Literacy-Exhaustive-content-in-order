# 🎭 Attention Mechanisms Cheat Sheet

## The Attention Avengers Quick Reference

| Character | Type | Superpower | When to Use | Advantage | Disadvantage |
|-----------|------|------------|-------------|-----------|--------------|
| 👯‍♀️ **SOFIA** | Soft | Sees everyone, weighted focus | Always! (Most common) | Smooth, differentiable | Can be unfocused |
| ⚡ **HILDA** | Hard | Laser focus on ONE | Binary decisions | Clear, efficient | Non-differentiable |
| 🪞 **SELENA** | Self | Friends talk to friends | Within sequences | Captures relationships | Quadratic complexity |
| 🌍 **GLORIA** | Global | Satellite view of all | Full context needed | Perfect understanding | Memory intensive |
| 🔍 **LOLA** | Local | Detective's magnifying glass | Long sequences | Fast, memory efficient | Limited context |
| 👁️ **HYDRA** | Multi-Head | Multiple expert eyes | Complex understanding | Rich representations | More parameters |
| ➕ **ADDY** | Additive | Generous judge (adds) | Variable input sizes | Flexible dimensions | Slower computation |
| ✖️ **MULTI** | Multiplicative | Strict judge (multiplies) | Fixed dimensions | Fast, amplifies matches | Dimension constraints |

## 🧠 Memory Tricks

### The Attention Family Tree
```
Attention Mechanisms
├── 👯‍♀️ Soft vs ⚡ Hard (How much focus?)
├── 🪞 Self vs 🌍 Cross (Who talks to whom?)
├── 🌍 Global vs 🔍 Local (How much context?)
├── 👁️ Single vs Multi-Head (How many perspectives?)
└── ➕ Additive vs ✖️ Multiplicative (How to score?)
```

### The "When in Doubt" Rules
1. **Start with SOFIA** (Soft Attention) - works 90% of the time
2. **Add HYDRA** (Multi-Head) for complex tasks
3. **Call LOLA** (Local) when sequences get too long
4. **Use SELENA** (Self) for internal relationships

### Real-World Analogies
- **Soft Attention** = Teacher looking at classroom (sees all, focuses more on some)
- **Hard Attention** = Spotlight on stage (one actor only)
- **Self-Attention** = Group chat (everyone can talk to everyone)
- **Global Attention** = Google Earth (see everything)
- **Local Attention** = Microscope (zoom into small area)
- **Multi-Head** = Panel of judges (each expert in different area)

## 🎯 Quick Decision Guide

**Need smooth gradients?** → 👯‍♀️ Soft
**Need fast inference?** → ⚡ Hard or 🔍 Local  
**Working with sequences?** → 🪞 Self
**Long documents?** → 🔍 Local
**Complex understanding?** → 👁️ Multi-Head
**Variable input sizes?** → ➕ Additive
**Fixed dimensions & speed?** → ✖️ Multiplicative

Remember: **SOFIA and HYDRA are your best friends** - they solve most problems!
