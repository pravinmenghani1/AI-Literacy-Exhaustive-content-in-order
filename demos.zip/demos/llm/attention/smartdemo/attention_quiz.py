#!/usr/bin/env python3
"""
🎮 ATTENTION AVENGERS QUIZ GAME 🎮
Test your knowledge of the attention superheroes!
"""

import random

class AttentionQuiz:
    def __init__(self):
        self.score = 0
        self.total_questions = 0
        
        self.questions = [
            {
                "question": "🎭 Which attention hero sees everyone but focuses more on some?",
                "options": ["A) ⚡ HILDA (Hard)", "B) 👯‍♀️ SOFIA (Soft)", "C) 🔍 LOLA (Local)", "D) 🪞 SELENA (Self)"],
                "correct": "B",
                "explanation": "👯‍♀️ SOFIA (Soft Attention) is the gentle observer who sees everyone with weighted focus!"
            },
            {
                "question": "🚀 You have a 10,000-word document. Which hero should you call?",
                "options": ["A) 🌍 GLORIA (Global)", "B) 🔍 LOLA (Local)", "C) 👁️ HYDRA (Multi-Head)", "D) ⚡ HILDA (Hard)"],
                "correct": "B", 
                "explanation": "🔍 LOLA (Local Attention) is perfect for long sequences - she's memory efficient!"
            },
            {
                "question": "🤝 Which hero makes friends talk to each other within the same group?",
                "options": ["A) 🪞 SELENA (Self)", "B) 🌍 GLORIA (Global)", "C) ➕ ADDY (Additive)", "D) ✖️ MULTI (Multiplicative)"],
                "correct": "A",
                "explanation": "🪞 SELENA (Self-Attention) is the social butterfly who connects everyone in the same sequence!"
            },
            {
                "question": "👁️ You need to understand colors, objects, and actions simultaneously. Who do you call?",
                "options": ["A) 👯‍♀️ SOFIA (Soft)", "B) ⚡ HILDA (Hard)", "C) 👁️ HYDRA (Multi-Head)", "D) 🔍 LOLA (Local)"],
                "correct": "C",
                "explanation": "👁️ HYDRA (Multi-Head Attention) has multiple expert eyes for different aspects!"
            },
            {
                "question": "⚡ Which hero makes the fastest, clearest decisions?",
                "options": ["A) 👯‍♀️ SOFIA (Soft)", "B) ⚡ HILDA (Hard)", "C) 🌍 GLORIA (Global)", "D) ➕ ADDY (Additive)"],
                "correct": "B",
                "explanation": "⚡ HILDA (Hard Attention) is the laser pointer - one clear choice, super fast!"
            },
            {
                "question": "🧮 Your inputs have different dimensions. Which scoring hero helps?",
                "options": ["A) ➕ ADDY (Additive)", "B) ✖️ MULTI (Multiplicative)", "C) 🪞 SELENA (Self)", "D) 🔍 LOLA (Local)"],
                "correct": "A",
                "explanation": "➕ ADDY (Additive Attention) is the generous judge who handles different input sizes!"
            },
            {
                "question": "🌍 Which hero never misses any connection in the entire sequence?",
                "options": ["A) 🔍 LOLA (Local)", "B) ⚡ HILDA (Hard)", "C) 🌍 GLORIA (Global)", "D) ✖️ MULTI (Multiplicative)"],
                "correct": "C",
                "explanation": "🌍 GLORIA (Global Attention) is the satellite who sees the entire picture!"
            },
            {
                "question": "💨 You need speed and want to amplify strong matches. Which scorer?",
                "options": ["A) ➕ ADDY (Additive)", "B) ✖️ MULTI (Multiplicative)", "C) 👁️ HYDRA (Multi-Head)", "D) 🪞 SELENA (Self)"],
                "correct": "B",
                "explanation": "✖️ MULTI (Multiplicative Attention) is the strict judge - fast and amplifies strong matches!"
            }
        ]
    
    def ask_question(self, q_data):
        print(f"\n{'='*60}")
        print(f"❓ {q_data['question']}")
        print("="*60)
        
        for option in q_data['options']:
            print(f"   {option}")
        
        while True:
            answer = input("\n🎯 Your answer (A/B/C/D): ").upper().strip()
            if answer in ['A', 'B', 'C', 'D']:
                break
            print("❌ Please enter A, B, C, or D")
        
        self.total_questions += 1
        
        if answer == q_data['correct']:
            self.score += 1
            print(f"\n🎉 CORRECT! {q_data['explanation']}")
        else:
            correct_option = q_data['options'][ord(q_data['correct']) - ord('A')]
            print(f"\n❌ Oops! The correct answer was {q_data['correct']}: {correct_option}")
            print(f"💡 {q_data['explanation']}")
    
    def run_quiz(self):
        print("🎮 WELCOME TO THE ATTENTION AVENGERS QUIZ! 🎮")
        print("🦸‍♀️ Test your knowledge of our attention superheroes!")
        print("🎯 Let's see if you remember their superpowers...")
        
        # Shuffle questions for variety
        quiz_questions = random.sample(self.questions, len(self.questions))
        
        for i, question in enumerate(quiz_questions, 1):
            print(f"\n🔢 Question {i}/{len(quiz_questions)}")
            self.ask_question(question)
            
            if i < len(quiz_questions):
                input("\n⏭️  Press Enter for next question...")
        
        self.show_results()
    
    def show_results(self):
        percentage = (self.score / self.total_questions) * 100
        
        print(f"\n{'🏆'*20}")
        print(f"🎯 QUIZ COMPLETE! 🎯")
        print(f"{'🏆'*20}")
        print(f"📊 Your Score: {self.score}/{self.total_questions} ({percentage:.1f}%)")
        
        if percentage >= 90:
            print("🌟 ATTENTION MASTER! You know all the heroes!")
            print("🦸‍♀️ You're ready to lead the Attention Avengers!")
        elif percentage >= 70:
            print("🎉 GREAT JOB! You know most of the heroes!")
            print("📚 Review a few more and you'll be perfect!")
        elif percentage >= 50:
            print("👍 GOOD START! You're learning the heroes!")
            print("🎭 Go back to the theater and meet them again!")
        else:
            print("🎪 TIME FOR A REWATCH! Visit the Attention Theater again!")
            print("🎭 Our heroes are waiting to teach you their powers!")
        
        print(f"\n🧠 Remember: The Attention Avengers are always here to help!")
        print(f"🎯 Each hero has a unique superpower for different situations!")

if __name__ == "__main__":
    quiz = AttentionQuiz()
    quiz.run_quiz()
