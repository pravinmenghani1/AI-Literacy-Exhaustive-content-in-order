#!/usr/bin/env python3
"""
🎪 ATTENTION MECHANISMS COMPLETE EXPERIENCE 🎪
Your one-stop shop for learning attention like never before!
"""

import subprocess
import sys
import os

def run_script(script_name):
    """Run a Python script and handle any errors"""
    try:
        subprocess.run([sys.executable, script_name], check=True)
    except subprocess.CalledProcessError as e:
        print(f"❌ Error running {script_name}: {e}")
    except FileNotFoundError:
        print(f"❌ File not found: {script_name}")

def show_menu():
    print("\n🎭 ATTENTION MECHANISMS LEARNING CENTER 🎭")
    print("="*50)
    print("1️⃣  🎪 Watch the Attention Theater (Enhanced Demo)")
    print("2️⃣  📚 View the Cheat Sheet")
    print("3️⃣  🎮 Take the Quiz")
    print("4️⃣  🔄 Run Original Demo (for comparison)")
    print("5️⃣  ❌ Exit")
    print("="*50)

def show_cheat_sheet():
    """Display the cheat sheet"""
    try:
        with open("attention_cheatsheet.md", "r") as f:
            content = f.read()
            print(content)
    except FileNotFoundError:
        print("❌ Cheat sheet not found!")

def main():
    print("🎉 WELCOME TO THE ULTIMATE ATTENTION LEARNING EXPERIENCE! 🎉")
    print("🧠 Prepare to meet the Attention Avengers and master AI attention!")
    
    while True:
        show_menu()
        
        try:
            choice = input("\n🎯 Choose your adventure (1-5): ").strip()
            
            if choice == "1":
                print("\n🎭 Starting the Attention Theater...")
                print("🍿 Grab some popcorn and enjoy the show!")
                run_script("enhanced_attention_demo.py")
                
            elif choice == "2":
                print("\n📚 Opening the Attention Cheat Sheet...")
                show_cheat_sheet()
                input("\n📖 Press Enter to return to menu...")
                
            elif choice == "3":
                print("\n🎮 Starting the Attention Quiz...")
                print("🧠 Time to test your knowledge!")
                run_script("attention_quiz.py")
                
            elif choice == "4":
                print("\n🔄 Running original demo for comparison...")
                if os.path.exists("attention_demo.py"):
                    run_script("attention_demo.py")
                else:
                    print("❌ Original demo not found!")
                
            elif choice == "5":
                print("\n👋 Thanks for learning about attention mechanisms!")
                print("🎭 The Attention Avengers will miss you!")
                print("🧠 Remember: Each hero has a unique superpower!")
                break
                
            else:
                print("❌ Invalid choice! Please enter 1-5.")
                
        except KeyboardInterrupt:
            print("\n\n👋 Goodbye! Come back anytime to meet the Attention Avengers!")
            break
        except Exception as e:
            print(f"❌ An error occurred: {e}")

if __name__ == "__main__":
    main()
