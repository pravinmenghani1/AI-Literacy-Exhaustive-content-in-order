#!/usr/bin/env python3
"""
🧠 Attention Types Demo - Explained Like You're 5! 🧠
Think of attention like how you pay attention to different things around you.
"""

import numpy as np

print("🎯 ATTENTION TYPES DEMO 🎯\n")

# 1. SOFT ATTENTION - Like looking at a whole classroom
print("1️⃣ SOFT ATTENTION - 'Looking at Everyone'")
print("Imagine you're a teacher looking at all students, but some catch your eye more!")

classroom = ["Alice", "Bob", "Charlie", "Diana"]
attention_weights = [0.4, 0.3, 0.2, 0.1]  # How much you focus on each student
print(f"Students: {classroom}")
print(f"Attention: {attention_weights} (adds up to 1.0)")
print("You see everyone, but Alice gets 40% of your attention!\n")

# 2. HARD ATTENTION - Like pointing at one thing
print("2️⃣ HARD ATTENTION - 'Pointing at One Thing'")
print("Like when mom says 'Look at ME!' - you focus on just one thing")

chosen_student = classroom[0]  # Pick just Alice
print(f"You point at: {chosen_student} (ignore everyone else!)\n")

# 3. SELF-ATTENTION - Like friends talking to each other
print("3️⃣ SELF-ATTENTION - 'Friends Talking to Friends'")
print("Each friend can talk to any other friend in the group")

friends = ["Amy", "Ben", "Cat"]
for friend in friends:
    print(f"{friend} can talk to: {[f for f in friends if f != friend]}")
print()

# 4. GLOBAL vs LOCAL ATTENTION
print("4️⃣ GLOBAL ATTENTION - 'Seeing the Whole Picture'")
story = ["Once", "upon", "a", "time", "there", "was", "a", "princess"]
print(f"Reading story: {' '.join(story)}")
print("You remember ALL words when understanding 'princess'\n")

print("5️⃣ LOCAL ATTENTION - 'Looking Through a Window'")
window_size = 3
current_word = 6  # "a"
window = story[max(0, current_word-1):current_word+2]
print(f"Current word: '{story[current_word]}'")
print(f"Window view: {window} (only nearby words)")
print()

# 6. MULTI-HEAD ATTENTION - Like having multiple eyes
print("6️⃣ MULTI-HEAD ATTENTION - 'Having Multiple Eyes'")
print("Like an alien with 3 eyes - each eye notices different things!")

sentence = ["The", "red", "car", "is", "fast"]
head1_focus = "color words"  # notices "red"
head2_focus = "object words"  # notices "car"  
head3_focus = "action words"  # notices "fast"

print(f"Sentence: {' '.join(sentence)}")
print(f"Eye 1 sees: {head1_focus}")
print(f"Eye 2 sees: {head2_focus}")
print(f"Eye 3 sees: {head3_focus}")
print("Then combine what all eyes saw!\n")

# 7. ADDITIVE vs MULTIPLICATIVE - Different ways to score
print("7️⃣ SCORING ATTENTION - 'How Much Do You Like Ice Cream?'")
print("Two ways to decide how much you like different flavors:")

flavors = ["vanilla", "chocolate", "strawberry"]
your_taste = [0.5, 0.8, 0.3]
flavor_quality = [0.7, 0.9, 0.6]

print("\nAdditive (Adding): Your taste + Flavor quality")
additive_scores = [t + q for t, q in zip(your_taste, flavor_quality)]
print(f"Scores: {[f'{f}: {s:.1f}' for f, s in zip(flavors, additive_scores)]}")

print("\nMultiplicative (Multiplying): Your taste × Flavor quality")  
multiplicative_scores = [t * q for t, q in zip(your_taste, flavor_quality)]
print(f"Scores: {[f'{f}: {s:.1f}' for f, s in zip(flavors, multiplicative_scores)]}")

print("\n🎉 That's how AI pays attention to different things! 🎉")
