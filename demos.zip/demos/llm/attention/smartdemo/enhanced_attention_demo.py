#!/usr/bin/env python3
"""
🎭 THE ATTENTION THEATER: A Journey Through AI's Mind 🎭
Where each attention type is a character with superpowers!
"""

import numpy as np
import time

def dramatic_pause():
    input("\n🎬 Press Enter to continue...")
    print()

def print_banner(title, emoji="🎯"):
    print(f"\n{'='*50}")
    print(f"{emoji} {title} {emoji}")
    print(f"{'='*50}")

def visualize_attention(weights, items, title):
    print(f"\n📊 {title}")
    for item, weight in zip(items, weights):
        bar = "█" * int(weight * 20)  # Visual bar
        print(f"{item:12} |{bar:<20}| {weight:.2f}")

print_banner("THE ATTENTION THEATER", "🎭")
print("🎪 Welcome to the most EPIC attention demo ever!")
print("Each attention type is a superhero with unique powers!")

dramatic_pause()

# 🔥 STORY 1: THE SPOTLIGHT SISTERS
print_banner("ACT 1: THE SPOTLIGHT SISTERS", "👯‍♀️")

print("🌟 Meet SOFIA (Soft Attention) - The Gentle Observer")
print("💪 SUPERPOWER: Sees everyone at once, gives partial attention")
print("🎯 ADVANTAGE: Never misses anything, smooth and differentiable")

classroom = ["🧑‍🎓 Alice", "👨‍🎓 Bob", "👩‍🎓 Charlie", "🧑‍🎓 Diana"]
sofia_weights = [0.5, 0.3, 0.15, 0.05]

print(f"\nSofia looks at the classroom: {classroom}")
visualize_attention(sofia_weights, classroom, "Sofia's Gentle Gaze")
print("✨ Sofia whispers: 'I see you all, but Alice shines brightest!'")

dramatic_pause()

print("\n⚡ Meet HILDA (Hard Attention) - The Laser Pointer")
print("💪 SUPERPOWER: Laser focus on ONE thing only")
print("🎯 ADVANTAGE: Crystal clear decisions, no confusion")

chosen_one = classroom[0]
hilda_weights = [1.0, 0.0, 0.0, 0.0]

print(f"\nHilda points her laser: *ZAP* → {chosen_one}")
visualize_attention(hilda_weights, classroom, "Hilda's Laser Focus")
print("⚡ Hilda shouts: 'ONLY ALICE EXISTS! Everyone else is invisible!'")

print("\n🥊 SOFIA vs HILDA SHOWDOWN:")
print("Sofia: 'I'm smooth and see the big picture!'")
print("Hilda: 'I'm decisive and save computational power!'")

dramatic_pause()

# 🔥 STORY 2: THE MIRROR MAGICIAN
print_banner("ACT 2: THE MIRROR MAGICIAN", "🪞")

print("🪞 Meet SELENA (Self-Attention) - The Social Butterfly")
print("💪 SUPERPOWER: Makes everyone talk to everyone!")
print("🎯 ADVANTAGE: Captures relationships within the same sequence")

friends = ["🦋 Amy", "🐝 Ben", "🐱 Cat", "🐶 Dan"]
print(f"\nSelena's magic circle: {friends}")

print("\n✨ *POOF* Selena waves her wand:")
for i, friend in enumerate(friends):
    connections = [f for j, f in enumerate(friends) if i != j]
    print(f"{friend} connects to: {', '.join(connections)}")

print("\n🌟 The magic result: Everyone knows everyone's secrets!")
print("Amy learns Ben's jokes, Cat's wisdom, Dan's loyalty!")

dramatic_pause()

# 🔥 STORY 3: THE TELESCOPE TWINS
print_banner("ACT 3: THE TELESCOPE TWINS", "🔭")

print("🌍 Meet GLORIA (Global Attention) - The Satellite")
print("💪 SUPERPOWER: Sees the ENTIRE planet at once")
print("🎯 ADVANTAGE: Perfect context, never misses connections")

story = ["🏰", "👸", "🐉", "⚔️", "💎", "👑", "🎉", "💕"]
story_words = ["Castle", "Princess", "Dragon", "Sword", "Gem", "Crown", "Party", "Love"]

print(f"\nGloria's satellite view of the story:")
for emoji, word in zip(story, story_words):
    print(f"{emoji} {word}", end="  ")
print(f"\n\nGloria sees ALL connections: Castle→Princess→Dragon→Victory!")

dramatic_pause()

print("\n🔍 Meet LOLA (Local Attention) - The Detective")
print("💪 SUPERPOWER: Magnifying glass focus on nearby clues")
print("🎯 ADVANTAGE: Efficient, fast, works with long sequences")

current_pos = 4  # Looking at "Gem"
window_size = 2
window_start = max(0, current_pos - window_size)
window_end = min(len(story), current_pos + window_size + 1)

print(f"\nLola's magnifying glass at position {current_pos} (Gem):")
print("Full story: " + " ".join([f"{e}{w}" for e, w in zip(story, story_words)]))
print("Lola sees: " + " ".join([f"{story[i]}{story_words[i]}" for i in range(window_start, window_end)]))
print("🔍 'I see Sword→Gem→Crown. That's enough to solve this mystery!'")

print("\n🥊 GLORIA vs LOLA BATTLE:")
print("Gloria: 'I see everything! Perfect understanding!'")
print("Lola: 'I'm lightning fast and memory efficient!'")

dramatic_pause()

# 🔥 STORY 4: THE MULTI-EYED MONSTER
print_banner("ACT 4: THE MULTI-EYED MONSTER", "👁️")

print("👁️‍🗨️ Meet HYDRA (Multi-Head Attention) - The All-Seeing Beast")
print("💪 SUPERPOWER: Multiple heads, each with different expertise")
print("🎯 ADVANTAGE: Captures different types of relationships simultaneously")

sentence = ["The", "🔴", "🚗", "is", "⚡"]
words = ["The", "red", "car", "is", "fast"]

print(f"\nHydra analyzes: {' '.join(words)}")
print("\n👁️ HEAD 1 (Color Expert): 'I see RED! Colors are my thing!'")
print("👁️ HEAD 2 (Object Expert): 'I see CAR! I know all objects!'")  
print("👁️ HEAD 3 (Action Expert): 'I see FAST! Speed is my domain!'")

# Simulate different attention patterns
color_attention = [0.1, 0.8, 0.05, 0.025, 0.025]
object_attention = [0.2, 0.1, 0.6, 0.05, 0.05]
action_attention = [0.05, 0.05, 0.1, 0.1, 0.7]

print(f"\n🧠 Hydra's combined wisdom:")
visualize_attention(color_attention, words, "Head 1: Color Focus")
visualize_attention(object_attention, words, "Head 2: Object Focus") 
visualize_attention(action_attention, words, "Head 3: Action Focus")

print("🔥 Result: 'A RED CAR that is FAST!' - Perfect understanding!")

dramatic_pause()

# 🔥 STORY 5: THE SCORING DUEL
print_banner("ACT 5: THE SCORING DUEL", "⚔️")

print("➕ Meet ADDY (Additive Attention) - The Generous Judge")
print("💪 SUPERPOWER: Adds scores together (query + key)")
print("🎯 ADVANTAGE: Handles different input sizes gracefully")

print("\n✖️ Meet MULTI (Multiplicative Attention) - The Strict Judge")
print("💪 SUPERPOWER: Multiplies scores (query × key)")
print("🎯 ADVANTAGE: Faster computation, amplifies strong matches")

candidates = ["🍦 Vanilla", "🍫 Chocolate", "🍓 Strawberry"]
your_preference = [0.6, 0.9, 0.4]
ice_cream_quality = [0.8, 0.7, 0.9]

print(f"\n🍨 The Great Ice Cream Contest!")
print(f"Candidates: {candidates}")
print(f"Your taste: {your_preference}")
print(f"Quality: {ice_cream_quality}")

print(f"\n➕ ADDY's method (Addition):")
additive_scores = [p + q for p, q in zip(your_preference, ice_cream_quality)]
for candidate, score in zip(candidates, additive_scores):
    print(f"{candidate}: {score:.1f}")

print(f"\n✖️ MULTI's method (Multiplication):")
multiplicative_scores = [p * q for p, q in zip(your_preference, ice_cream_quality)]
for candidate, score in zip(candidates, multiplicative_scores):
    print(f"{candidate}: {score:.1f}")

winner_add = candidates[np.argmax(additive_scores)]
winner_mult = candidates[np.argmax(multiplicative_scores)]

print(f"\n🏆 ADDY picks: {winner_add}")
print(f"🏆 MULTI picks: {winner_mult}")

dramatic_pause()

# 🔥 GRAND FINALE
print_banner("GRAND FINALE: THE ATTENTION AVENGERS ASSEMBLE!", "🦸‍♀️")

print("🎭 Our heroes have shown their powers!")
print("\n📚 MEMORY PALACE - Remember them by their superpowers:")
print("👯‍♀️ SOFIA (Soft): The gentle teacher who sees all students")
print("⚡ HILDA (Hard): The laser pointer that picks ONE")
print("🪞 SELENA (Self): The mirror that connects friends")
print("🌍 GLORIA (Global): The satellite with full view")
print("🔍 LOLA (Local): The detective with magnifying glass")
print("👁️ HYDRA (Multi-Head): The monster with expert eyes")
print("➕ ADDY (Additive): The generous judge who adds")
print("✖️ MULTI (Multiplicative): The strict judge who multiplies")

print("\n🎯 WHEN TO CALL EACH HERO:")
print("🔥 Need smooth gradients? Call SOFIA!")
print("⚡ Need fast decisions? Call HILDA!")
print("🤝 Need internal relationships? Call SELENA!")
print("🌍 Need full context? Call GLORIA!")
print("🚀 Need efficiency? Call LOLA!")
print("🧠 Need multiple perspectives? Call HYDRA!")
print("📏 Different input sizes? Call ADDY!")
print("💨 Need speed and strong matches? Call MULTI!")

print("\n🎉 THE END - You now know the Attention Avengers! 🎉")
print("🧠 Your brain will remember these characters forever!")
