import matplotlib.pyplot as plt
import numpy as np

# Simple test plot
x = np.linspace(0, 10, 100)
y = np.sin(x)

plt.figure(figsize=(8, 6))
plt.plot(x, y)
plt.title('Test Plot - If you see this, matplotlib is working!')
plt.xlabel('X')
plt.ylabel('Y')
plt.grid(True)
plt.show()

input("Press Enter to close...")
