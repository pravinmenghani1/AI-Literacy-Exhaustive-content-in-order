#!/usr/bin/env python3
"""
🎭 Generative Models Interactive Demo Suite
==========================================

This script runs all the generative model demonstrations:
- GANs: Adversarial training and mode collapse
- VAEs: Latent space and reconstruction  
- Diffusion: Denoising process and controllability

Run this to see all models in action!
"""

import sys
import subprocess
import importlib.util

def check_dependencies():
    """Check if required packages are installed"""
    required_packages = ['numpy', 'matplotlib', 'torch', 'sklearn']
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package)
        except ImportError:
            missing_packages.append(package)
    
    if missing_packages:
        print("❌ Missing required packages:")
        for pkg in missing_packages:
            print(f"   • {pkg}")
        print(f"\n📦 Install with: pip install {' '.join(missing_packages)}")
        return False
    
    print("✅ All dependencies found!")
    return True

def run_demo(demo_name, demo_file):
    """Run a specific demo with error handling"""
    print(f"\n{'='*60}")
    print(f"🚀 Running {demo_name}")
    print(f"{'='*60}")
    
    try:
        # Import and run the demo
        spec = importlib.util.spec_from_file_location(demo_name, demo_file)
        demo_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(demo_module)
        
        print(f"✅ {demo_name} completed successfully!")
        
    except Exception as e:
        print(f"❌ Error running {demo_name}: {str(e)}")
        print("Continuing with next demo...")

def main():
    """Main function to run all demos"""
    print("🎭 GENERATIVE MODELS DEMO SUITE")
    print("=" * 50)
    print("Interactive demonstrations of GANs, VAEs, and Diffusion Models")
    print("Close matplotlib windows to proceed to the next demo.\n")
    
    # Check dependencies first
    if not check_dependencies():
        print("\n❌ Please install missing packages before running demos.")
        return
    
    # List of demos to run
    demos = [
        ("GAN Demo", "gan_demo.py"),
        ("VAE Demo", "vae_demo.py"), 
        ("Diffusion Demo", "diffusion_demo.py")
    ]
    
    # Ask user which demos to run
    print("Which demos would you like to run?")
    print("1. All demos (recommended)")
    print("2. Individual demo selection")
    print("3. Just run the quiz")
    
    choice = input("\nEnter your choice (1/2/3): ").strip()
    
    if choice == "3":
        print("\n🧠 Starting Quiz...")
        run_demo("Quiz", "generative_models_quiz.py")
        return
    elif choice == "2":
        print("\nSelect demos to run:")
        selected_demos = []
        for i, (name, file) in enumerate(demos, 1):
            run_it = input(f"Run {name}? (y/n): ").lower().startswith('y')
            if run_it:
                selected_demos.append((name, file))
        demos = selected_demos
    
    # Run selected demos
    for demo_name, demo_file in demos:
        run_demo(demo_name, demo_file)
        
        if demo_name != demos[-1][0]:  # Not the last demo
            input(f"\n⏸️  Press Enter to continue to next demo...")
    
    # Ask if user wants to take the quiz
    print(f"\n🎓 Demos complete! Ready to test your knowledge?")
    take_quiz = input("Take the quiz? (y/n): ").lower().startswith('y')
    
    if take_quiz:
        run_demo("Quiz", "generative_models_quiz.py")
    
    print(f"\n🎉 All done! Thanks for exploring generative models!")
    print("💡 Try modifying the demo code to experiment further!")

if __name__ == "__main__":
    main()
