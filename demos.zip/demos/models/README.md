# 🎭 Generative Models Interactive Demo Suite

An educational toolkit for understanding **GANs**, **VAEs**, and **Diffusion Models** through interactive visualizations and comprehensive quizzes.

## 🚀 Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Run all demos
python run_all_demos.py

# Or run individual demos
python gan_demo.py
python vae_demo.py  
python diffusion_demo.py

# Take the quiz
python generative_models_quiz.py
```

## 📚 What You'll Learn

### 🎯 GANs (Generative Adversarial Networks)
- **Adversarial Training**: See Generator vs Discriminator battle
- **Mode Collapse**: Understand training instability issues
- **Sharp Outputs**: Why GANs produce realistic images
- **Use Cases**: Deepfakes, StyleGAN, image-to-image translation

### 🧠 VAEs (Variational Autoencoders)  
- **Latent Space**: Explore smooth, continuous representations
- **Interpolation**: See how VAEs enable smooth transitions
- **Anomaly Detection**: Learn reconstruction-based detection
- **Stability**: Understand why VAEs train reliably

### 🌊 Diffusion Models
- **Denoising Process**: Watch noise transform into images
- **Text Control**: See how prompts guide generation
- **Quality vs Speed**: Understand the trade-offs
- **State-of-the-art**: Why they power DALL-E, Stable Diffusion

## 🎮 Interactive Features

### Visual Demonstrations
- **Real-time Training**: Watch models learn step by step
- **Side-by-side Comparisons**: See quality differences
- **Process Visualization**: Understand how each model works
- **Trade-off Analysis**: Speed vs Quality vs Stability

### Comprehensive Quiz
- **Multiple Choice**: Test conceptual understanding
- **Scenario-based**: Apply knowledge to real problems  
- **Technical Deep-dive**: Understand implementation details
- **Performance Analysis**: Get personalized feedback

## 📊 Demo Highlights

### GAN Demo (`gan_demo.py`)
```
🎭 Shows:
• Generator improving over training epochs
• Discriminator accuracy decreasing as generator gets better
• Mode collapse visualization
• Sharp vs diverse output comparison
```

### VAE Demo (`vae_demo.py`)
```
🧠 Shows:
• Data compression to latent space
• Smooth interpolation between points
• Anomaly detection through reconstruction error
• Blurry but stable outputs
```

### Diffusion Demo (`diffusion_demo.py`)
```
🌊 Shows:
• Forward noise addition process
• Reverse denoising step-by-step
• Text-to-image controllability
• Speed vs quality trade-offs
```

## 🎯 Learning Path

1. **Start with Concepts**: Read the comparison table
2. **Run Demos**: See models in action
3. **Take Quiz**: Test your understanding
4. **Experiment**: Modify code parameters
5. **Build Projects**: Apply to real problems

## 🔧 Technical Requirements

- Python 3.7+
- NumPy (numerical computing)
- Matplotlib (visualizations)
- PyTorch (neural networks)
- Scikit-learn (data utilities)

## 📈 Quiz Scoring

- **🏆 Expert (90%+)**: Ready for advanced research
- **🥇 Advanced (80-89%)**: Strong practical understanding  
- **🥈 Proficient (70-79%)**: Good foundation, minor gaps
- **🥉 Intermediate (60-69%)**: Basic concepts understood
- **📚 Beginner (<60%)**: Review fundamentals

## 🎨 Customization Ideas

### Modify Parameters
```python
# In gan_demo.py - change training epochs
epochs = [0, 10, 50, 100, 500, 1000]

# In vae_demo.py - adjust latent dimensions  
latent_dim = 4  # Try 2, 4, 8, 16

# In diffusion_demo.py - change denoising steps
timesteps = [0, 10, 25, 50, 75, 100]
```

### Add New Visualizations
- Training loss curves
- Latent space clustering
- Generation diversity metrics
- Computational cost analysis

## 🌟 Real-World Applications

### GANs
- **DeepFakes**: Face swapping in videos
- **StyleGAN**: Photorealistic face generation
- **Pix2Pix**: Sketch to photo conversion
- **CycleGAN**: Style transfer (horses ↔ zebras)

### VAEs  
- **Anomaly Detection**: Fraud detection, medical imaging
- **Drug Discovery**: Exploring chemical compound spaces
- **Recommendation Systems**: User/item embeddings
- **Data Compression**: Meaningful representations

### Diffusion Models
- **Text-to-Image**: DALL-E 3, Stable Diffusion, MidJourney
- **Video Generation**: OpenAI Sora, Amazon Nova Reel
- **Audio Synthesis**: Stable Audio, music generation
- **Scientific Modeling**: Protein folding, molecular design

## 🤝 Contributing

Want to improve the demos? Ideas welcome:
- Add new model architectures (Transformers, Flow-based)
- Create more interactive visualizations
- Expand quiz question bank
- Add real dataset examples

## 📖 Further Reading

- **GANs**: "Generative Adversarial Networks" (Goodfellow et al.)
- **VAEs**: "Auto-Encoding Variational Bayes" (Kingma & Welling)  
- **Diffusion**: "Denoising Diffusion Probabilistic Models" (Ho et al.)
- **Practical Guide**: "Deep Learning" (Goodfellow, Bengio, Courville)

---

**Happy Learning! 🎓** 

*Master generative AI through hands-on exploration and interactive understanding.*
