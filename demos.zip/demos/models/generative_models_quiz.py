import random
import json
from typing import List, Dict, Any

class GenerativeModelsQuiz:
    def __init__(self):
        self.score = 0
        self.total_questions = 0
        self.questions = self.load_questions()
        
    def load_questions(self) -> List[Dict[str, Any]]:
        """Load all quiz questions"""
        return [
            # Multiple Choice Questions
            {
                "type": "multiple_choice",
                "question": "What is the main training challenge with GANs?",
                "options": [
                    "A) Too slow inference",
                    "B) Mode collapse and training instability", 
                    "C) Blurry outputs",
                    "D) High memory usage"
                ],
                "correct": "B",
                "explanation": "GANs suffer from mode collapse (generator produces limited variety) and unstable adversarial training between generator and discriminator."
            },
            {
                "type": "multiple_choice", 
                "question": "Which model is best for anomaly detection?",
                "options": [
                    "A) GANs",
                    "B) VAEs",
                    "C) Diffusion Models", 
                    "D) All are equally good"
                ],
                "correct": "B",
                "explanation": "VAEs learn meaningful latent representations and can detect anomalies through reconstruction error - if input can't be reconstructed well, it's abnormal."
            },
            {
                "type": "multiple_choice",
                "question": "What makes Diffusion Models slow during inference?",
                "options": [
                    "A) Large model size",
                    "B) Complex architecture",
                    "C) Multiple denoising steps required",
                    "D) GPU memory limitations"
                ],
                "correct": "C", 
                "explanation": "Diffusion models require many sequential denoising steps (often 50-1000) to gradually convert noise into the final image, making inference slow."
            },
            {
                "type": "multiple_choice",
                "question": "Which model produces the sharpest, most realistic images?",
                "options": [
                    "A) VAEs",
                    "B) GANs", 
                    "C) Diffusion Models",
                    "D) Both B and C"
                ],
                "correct": "D",
                "explanation": "Both GANs and Diffusion Models can produce very sharp, realistic images. GANs are fast but unstable, while Diffusion Models are slower but more controllable."
            },
            
            # True/False Questions
            {
                "type": "true_false",
                "question": "VAEs always produce blurrier outputs compared to GANs.",
                "correct": True,
                "explanation": "True. VAEs optimize for reconstruction likelihood which leads to averaging effects and blurrier outputs, while GANs focus on fooling the discriminator leading to sharper images."
            },
            {
                "type": "true_false", 
                "question": "Diffusion models require adversarial training like GANs.",
                "correct": False,
                "explanation": "False. Diffusion models don't use adversarial training. They learn to reverse a noise process through standard supervised learning, making training more stable."
            },
            {
                "type": "true_false",
                "question": "VAEs learn a continuous latent space good for interpolation.",
                "correct": True,
                "explanation": "True. VAEs explicitly learn a smooth, continuous latent space where similar inputs map to nearby points, enabling smooth interpolation between different samples."
            },
            
            # Scenario-based Questions
            {
                "type": "scenario",
                "question": "You need to generate realistic human faces for a mobile app with real-time requirements. Which model would you choose?",
                "options": [
                    "A) VAE - stable and fast",
                    "B) GAN - fast inference, sharp faces",
                    "C) Diffusion Model - highest quality",
                    "D) Any model works fine"
                ],
                "correct": "B",
                "explanation": "GANs are ideal here because: 1) Fast inference for real-time use, 2) Excel at generating sharp, realistic faces (StyleGAN), 3) Mobile apps need speed over perfect quality."
            },
            {
                "type": "scenario", 
                "question": "You're building a fraud detection system for credit card transactions. Which model fits best?",
                "options": [
                    "A) GAN - generates realistic fake transactions",
                    "B) VAE - detects anomalies via reconstruction error", 
                    "C) Diffusion Model - highest accuracy",
                    "D) None of these models apply"
                ],
                "correct": "B",
                "explanation": "VAEs are perfect for anomaly detection. Normal transactions reconstruct well (low error), while fraudulent ones have high reconstruction error since they're outside the learned distribution."
            },
            {
                "type": "scenario",
                "question": "An artist wants to create high-quality, creative artwork from text descriptions. What's the best choice?",
                "options": [
                    "A) GAN - fastest generation",
                    "B) VAE - most stable",
                    "C) Diffusion Model - controllable, high-quality",
                    "D) Combine all three models"
                ],
                "correct": "C", 
                "explanation": "Diffusion models excel at text-to-image generation (DALL-E, Stable Diffusion) with fine control over style, composition, and quality - perfect for creative applications."
            },
            
            # Technical Deep-dive Questions
            {
                "type": "technical",
                "question": "In a GAN, what happens during mode collapse?",
                "options": [
                    "A) Discriminator becomes too powerful",
                    "B) Generator finds one solution and stops exploring diversity",
                    "C) Training loss explodes", 
                    "D) Model runs out of memory"
                ],
                "correct": "B",
                "explanation": "Mode collapse occurs when the generator discovers one or few 'easy' ways to fool the discriminator and stops exploring the full data distribution, leading to repetitive, low-diversity outputs."
            },
            {
                "type": "technical",
                "question": "What is the key difference between VAE and standard autoencoder latent spaces?",
                "options": [
                    "A) VAE latent space is smaller",
                    "B) VAE latent space is regularized to be continuous and smooth",
                    "C) VAE latent space is faster to compute",
                    "D) No significant difference"
                ],
                "correct": "B",
                "explanation": "VAEs use KL divergence loss to regularize the latent space to follow a prior distribution (usually Gaussian), making it continuous and enabling smooth interpolation and sampling."
            },
            
            # Application Matching
            {
                "type": "matching",
                "question": "Match the application to the best model type:",
                "pairs": {
                    "DeepFakes/Face swapping": "GAN",
                    "Drug discovery (exploring chemical space)": "VAE", 
                    "Text-to-image art generation": "Diffusion",
                    "Real-time style transfer": "GAN"
                },
                "explanation": "GANs excel at realistic face generation and fast style transfer. VAEs are great for exploring smooth spaces like chemical compounds. Diffusion models lead in controllable, high-quality text-to-image generation."
            }
        ]
    
    def run_quiz(self):
        """Run the complete quiz"""
        print("🧠 GENERATIVE MODELS MASTERY QUIZ")
        print("=" * 50)
        print("Test your understanding of GANs, VAEs, and Diffusion Models!")
        print("Answer all questions to get your final score.\n")
        
        # Shuffle questions for variety
        quiz_questions = random.sample(self.questions, len(self.questions))
        
        for i, question in enumerate(quiz_questions, 1):
            print(f"\n📝 Question {i}/{len(quiz_questions)}")
            print("-" * 30)
            
            if question["type"] == "multiple_choice" or question["type"] == "scenario" or question["type"] == "technical":
                self.ask_multiple_choice(question)
            elif question["type"] == "true_false":
                self.ask_true_false(question)
            elif question["type"] == "matching":
                self.ask_matching(question)
        
        self.show_final_results()
    
    def ask_multiple_choice(self, question: Dict[str, Any]):
        """Handle multiple choice questions"""
        print(f"❓ {question['question']}\n")
        
        for option in question['options']:
            print(f"   {option}")
        
        while True:
            answer = input("\nYour answer (A/B/C/D): ").upper().strip()
            if answer in ['A', 'B', 'C', 'D']:
                break
            print("Please enter A, B, C, or D")
        
        self.total_questions += 1
        if answer == question['correct']:
            print("✅ Correct!")
            self.score += 1
        else:
            print(f"❌ Incorrect. The correct answer is {question['correct']}")
        
        print(f"💡 Explanation: {question['explanation']}")
    
    def ask_true_false(self, question: Dict[str, Any]):
        """Handle true/false questions"""
        print(f"❓ {question['question']}")
        
        while True:
            answer = input("\nTrue or False? (T/F): ").upper().strip()
            if answer in ['T', 'F', 'TRUE', 'FALSE']:
                break
            print("Please enter T/F or True/False")
        
        user_answer = answer.startswith('T')
        self.total_questions += 1
        
        if user_answer == question['correct']:
            print("✅ Correct!")
            self.score += 1
        else:
            correct_text = "True" if question['correct'] else "False"
            print(f"❌ Incorrect. The correct answer is {correct_text}")
        
        print(f"💡 Explanation: {question['explanation']}")
    
    def ask_matching(self, question: Dict[str, Any]):
        """Handle matching questions"""
        print(f"❓ {question['question']}\n")
        
        applications = list(question['pairs'].keys())
        models = ['GAN', 'VAE', 'Diffusion']
        
        print("Applications:")
        for i, app in enumerate(applications, 1):
            print(f"   {i}. {app}")
        
        print(f"\nModels: {', '.join(models)}")
        
        user_matches = {}
        for i, app in enumerate(applications, 1):
            while True:
                answer = input(f"\nMatch application {i} to model (GAN/VAE/Diffusion): ").strip()
                if answer in models:
                    user_matches[app] = answer
                    break
                print("Please enter GAN, VAE, or Diffusion")
        
        # Check answers
        correct_count = 0
        for app, correct_model in question['pairs'].items():
            if user_matches.get(app) == correct_model:
                correct_count += 1
        
        self.total_questions += 1
        if correct_count == len(question['pairs']):
            print("✅ Perfect match!")
            self.score += 1
        else:
            print(f"❌ {correct_count}/{len(question['pairs'])} correct matches")
            print("Correct matches:")
            for app, model in question['pairs'].items():
                print(f"   • {app} → {model}")
        
        print(f"💡 Explanation: {question['explanation']}")
    
    def show_final_results(self):
        """Display final quiz results with performance analysis"""
        print("\n" + "=" * 50)
        print("🎯 QUIZ COMPLETE - FINAL RESULTS")
        print("=" * 50)
        
        percentage = (self.score / self.total_questions) * 100
        print(f"📊 Score: {self.score}/{self.total_questions} ({percentage:.1f}%)")
        
        # Performance categories
        if percentage >= 90:
            grade = "🏆 EXPERT"
            message = "Outstanding! You have mastered generative models!"
        elif percentage >= 80:
            grade = "🥇 ADVANCED" 
            message = "Excellent understanding! You're ready for advanced applications."
        elif percentage >= 70:
            grade = "🥈 PROFICIENT"
            message = "Good grasp of concepts. Review weak areas for mastery."
        elif percentage >= 60:
            grade = "🥉 INTERMEDIATE"
            message = "Solid foundation. Focus on practical applications and differences."
        else:
            grade = "📚 BEGINNER"
            message = "Keep studying! Review the core concepts and try again."
        
        print(f"🎖️  Grade: {grade}")
        print(f"💬 {message}")
        
        # Study recommendations
        print(f"\n📖 Study Recommendations:")
        if percentage < 70:
            print("   • Review GAN training dynamics and mode collapse")
            print("   • Understand VAE latent space properties") 
            print("   • Learn diffusion model denoising process")
        elif percentage < 85:
            print("   • Practice identifying best model for specific use cases")
            print("   • Dive deeper into technical implementation details")
        else:
            print("   • Explore cutting-edge research papers")
            print("   • Try implementing models from scratch")
        
        print(f"\n🚀 Next Steps:")
        print("   • Run the demo scripts to see models in action")
        print("   • Experiment with real implementations")
        print("   • Build your own generative model project!")

def main():
    """Main function to run the quiz"""
    quiz = GenerativeModelsQuiz()
    
    print("Welcome to the Generative Models Quiz!")
    print("This quiz will test your understanding of:")
    print("• GANs (Generative Adversarial Networks)")
    print("• VAEs (Variational Autoencoders)")  
    print("• Diffusion Models")
    print("\nReady to begin? (Press Enter to start)")
    input()
    
    quiz.run_quiz()

if __name__ == "__main__":
    main()
